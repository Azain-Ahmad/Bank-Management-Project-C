#include <stdio.h>
#include <string.h>

void create_account(); 
void deposit_money();
void withdraw_money();
void check_balance();

const char* Account_FILE = "account.dat";

typedef struct 
{              
    char name[100];
    int acc_no;
    float balance;
} Account;

int main()
{
    char password[20];
    printf("Enter Admin Password to Access the System: ");
    scanf("%s", password);

    if (strcmp(password, "ABC") != 0)
    {
        printf("Access Denied! Incorrect Password.\n");
        return 0;
    }
    printf("Access Granted. Welcome to the Bank Management System.\n");

    int choice;
    while (1)
    {
        printf("\n\n ******* Bank Managment System *****");
        printf("\n1. Please Create Your Account");
        printf("\n2. Deposit Money");
        printf("\n3. Withdraw Money");
        printf("\n4. Check Balance");
        printf("\n5. Exit");

        printf("\nEnter Your Choice Please :");
        scanf("%d", &choice);
        switch (choice)
        {
        case 1:
            create_account();
            break;
        case 2:
            deposit_money();
            break;
        case 3:
            withdraw_money();
            break;
        case 4:
            check_balance();
            break;
        case 5:
            printf("\nClosing The Bank Thanks For Your Visit\n");
            return 0;
        default:
            printf("\nYou Entered an Invalid Choice!");
            break;
        }
    }
}

void create_account()
{
    Account acc;
    Account acc_r; 

    FILE *file = fopen(Account_FILE, "ab+");
    if(file == NULL)
    {
        printf("\nUnable To Open File!!");
        return;
    }

    char c;
    do
    {
        c = getchar();
    }
    while(c != '\n' && c != EOF);
    
    printf("Please Enter Your Name :");
    fgets(acc.name, sizeof(acc.name), stdin);
    int ind = strcspn(acc.name, "\n");
    acc.name[ind] = '\0';

    printf("Enter Your Account Number :");
    scanf("%d", &acc.acc_no);
    acc.balance = 0;

    rewind(file);
    while (fread(&acc_r, sizeof(acc_r), 1, file))
    {
        if (acc_r.acc_no == acc.acc_no)
        {
            printf("Account number already exists. Please use a different one.\n");
            fclose(file);
            return;
        }
    }

    fwrite(&acc, sizeof(acc), 1, file);
    fclose(file);
    printf("\nYour Account is Created Successfully!");
}

void deposit_money()
{
    FILE *file = fopen(Account_FILE, "rb+");
    if(file == NULL)
    {
        printf("\nUnable To Open File!!");
        return;
    }

    int acc_no;
    float deposit_money;
    Account acc_r;

    printf("Enter Your Account Number :");
    scanf("%d", &acc_no);

    printf("Enter The Amount To Deposit :");
    scanf("%f", &deposit_money);

    while(fread(&acc_r, sizeof(acc_r), 1, file))
    {
        if(acc_r.acc_no == acc_no)
        {
            acc_r.balance += deposit_money;
            fseek(file, -(long)sizeof(acc_r), SEEK_CUR);
            fwrite(&acc_r, sizeof(acc_r), 1, file);
            fclose(file);
            printf("Successfully Deposited RS.%.2f\nNew Balance is %.2f", deposit_money, acc_r.balance);
            return;
        }
    }
    fclose(file);
    printf("Deposit failed: Account Number %d not found in records\n", acc_no);
}

void withdraw_money()
{
    FILE *file = fopen(Account_FILE, "rb+");
    if(file == NULL)
    {
        printf("\nUnable To Open File!!");
        return;
    }

    int acc_no;
    float withdraw_money;
    Account acc_r;

    printf("Enter Your Account Number :");
    scanf("%d", &acc_no);

    printf("Enter The Amount You Wish To Withdraw :");
    scanf("%f", &withdraw_money);

    while(fread(&acc_r, sizeof(acc_r), 1, file))
    {
        if(acc_r.acc_no == acc_no)
        {
            if(acc_r.balance >= withdraw_money)
            {
                acc_r.balance -= withdraw_money;
                fseek(file, -(long)sizeof(acc_r), SEEK_CUR);
                fwrite(&acc_r, sizeof(acc_r), 1, file);
                printf("Successfully Withdrawn RS.%.2f\nNew Balance is RS. %.2f", withdraw_money, acc_r.balance);
            }
            else
            {
                printf("Insufficient Balance!!!");
            }
            fclose(file);
            return;
        }
    }

    fclose(file);
    printf("Withdrawal failed: Account Number %d not found in records\n", acc_no);
}

void check_balance()
{
    FILE *file = fopen(Account_FILE, "rb");
    if(file == NULL)
    {
        printf("\nUnable To Open File!!");
        return;
    }

    int acc_no;
    Account acc_read;

    printf("Enter Your Account Number :");
    scanf("%d", &acc_no);

    while(fread(&acc_read, sizeof(acc_read), 1, file))
    {
        if(acc_read.acc_no == acc_no)
        {
            printf("\nAccount Holder: %s", acc_read.name);
            printf("\nAccount Number: %d", acc_read.acc_no);
            printf("\nYour Current Balance is RS %.2f", acc_read.balance);
            fclose(file);
            return;
        }
    }
    fclose(file);
    printf("\nAccount Number: %d Was Not Found.\n", acc_no);
}

#include<stdio.h>

int main()
{
    int num;
    printf(" Enter the number :\n");
    scanf("%d" ,&num);
    if (num>=0)
    {
        printf("The number is positive\n");
        }
        if(num %2==0)
        {
            printf("It is ");
        }
        if(num %2 !=0)
        printf("It is odd number");
        else{
            printf("The number is not of our desired type");
        }
        return 0;

    }

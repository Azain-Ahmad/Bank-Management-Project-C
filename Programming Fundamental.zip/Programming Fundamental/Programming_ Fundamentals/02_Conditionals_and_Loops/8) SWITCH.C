#include<stdio.h>
int main()
{
    // int day(1-7);
    // printf("Enter the day :");
    // scanf("%d" ,&day);
    // switch (day)
    // {
    //     case 1 :printf("MONDAY\n");
    //     break;
    //     case 2 :printf("TUESDAY\n");
    //     break;
    //     case 3 :printf("WEDNESDAY\n");
    //     break;
    //     case 4 :printf("THIRSDAY\n");
    //     break;
    //     case 5 :printf("FRIDAY\n");
    //     break;
    //     case 6 :printf("SATURDAY\n");
    //     break;
    //     case 7 :printf("SUNDAY\n");
    //     break;
    //     default : printf("It is not a valid day\n");
    //     }

    // int time(1-5);
    // printf("enter the time :");
    // scanf("%d" ,&time);
    
    // switch (time)
    // {
    //     case 1 :printf("It is the time of Fajr prayer\n");
    //     break;
    //     case 2 :printf("It is the time of Zuhr prayer\n");
    //     break;
    //     case 3 :printf("It is the time of Aasr prayer\n");
    //     break;
    //     case 4 :printf("It is the time of Maghrib prayer\n");
    //     break;
    //     case 5 :printf("It is the time of Isha prayer\n");
    //     break;
    //     default:printf("1)It is not the time of any prayer\n2)You are late\n3)I request you to please come for prayer in time");
    //     return 0;
    // }

    char day;
    printf("Enter the day :");
    scanf("%s" ,&day);

    switch(day)
    {
        case 'a' :printf("It is MONDAY\n");
        break;
        
        case 'b' :printf("It is TUESDAY\n");
        break;
        
        case 'c' :printf("It is WEDNESDAY\n");
        break;
        
        case 'd' :printf("It is THRUSDAY\n");
        break;

    
        case 'e': printf("It is FRIDAY\n");
        break;
        
        case 'f' :printf("It is SATURDAY\n");
        break;
        
        case 'g' :printf("It is SUNDAY\n");
        break;
        default :printf("I dont know today is which day\n");

    }

        return 0;

        
    }






#include<stdio.h>

int main()
{
// for (int i=1; i<=5; i++) 
// {
// if(i==3)
// {
// break;
// }
// printf("%d\n" ,i);
// }
// printf("The program is end\n");

// keep taking number as input from usser until user enter an odd number

int n;
// printf("Enter the number :" );
// scanf("%d" ,&n);

for(;;)
{
if(n%2 !=0)
{
printf("%d is odd success\n" ,n);
break;
}
else
{
    printf("%d is even\n try again\n" ,n);
    
    printf("Enter the number :");
    scanf("%d" ,&n);
}

}
printf("JAZAKALLAH");
return 0;

}




// Infinite for loop
// int n;
// for (;;)
// {
// printf("Enter the number: ");
// scanf("%d",&n);

// // Check if the entered number is odd
// if (n % 2 != 0)
// {
// break; // Exit the loop if the number is odd
// }

// printf("%d is even. Try again.\n", n);
// }

// printf("JAZAKALLAH. You entered an odd number.\n");




// // Keep taking number as input from user untill user enter a number which is multiple of 7


// #include<stdio.h>

// int main()
// {
// int marks(0-100);
// printf("Enter the marks :\n");
// scanf("%d" ,&marks);

// if(marks>=50  && marks<=100)
// {
// printf("You got 1st position\n");
// }
// else if(marks<40 && marks<=30)
// {
// printf("You got 2nd position\n");
// }
// else
// {
//     printf("You fail the exam\nTry next time\n");
// }
// return 0;
// }

// #include<stdio.h>

// int main()
// {
// int marks(0-100);
// printf("Enter the marks :\n");
// scanf("%d" ,&marks);

// if(marks <30 )
// {
// printf("Ahmad got C grade\n");
// }
// else if(marks>=30 && marks<70)
// {
// printf("Ahmad got B grade\n");
// }
// else if(marks>=70 && marks<90)
// {
// printf(" Ahmad got A grade\n");
// }
// else if(marks >=90 && marks<=100)
// {
// printf("Ahmad got A+ grade\n");
// }
// else
// {
// printf("Invalid marks\n");
// }
// return 0;
// }

// #include<stdio.h>
// int main()
// {
// int x=2;
// printf("enter the number");
// // (    in this assingment operator is used to check the condition as we know that assingment operator is used to 
// //assign values  in this question we use = operator which give valuue to the x and the valuse of 
// // x is changed from  x=2 to x=4 )  and the condition is truse

// // but if we use 0 instead of any number greater than 0 then the value of x will be 0 and the condition will be false
// if(x=4)
// {
// printf("x is equal to 1");
// }
// else
// {
//     printf("x is not equal to 1");
// }
// return 0;
// }


#include<stdio.h>

int main()
{
int ch;
printf(" Enter the chractor :\n");
scanf("%c" ,&ch);

// WE CAN ALSO USE ASSCII VALUES OF ALPHABET INSTEAD OF ABC...Z AND abc...z
if(ch>= 'a' && ch <='z')
{
printf("This is a lower case letter\n");
}
else if(ch>='A'&& ch<='Z')
{
printf("This is the upper case letter\n");
}
else 
{
    printf("This is not an alphabet\n");
}
return 0;
}
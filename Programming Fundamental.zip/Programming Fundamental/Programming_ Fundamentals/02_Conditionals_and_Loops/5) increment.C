#include<stdio.h>
// i++ is pre-increment operator : if we use i++ then it first use  the value of variable and then increase  the value of variable
//++i is post-increment operator : if we use ++i then it first increse the value of variable and then use the value of variable

int main()
{
// int i=1;

//  if we use i++ then it first use  the value of variable and then increase  the value of variable
// printf("%d\n" ,i++);
// printf("%d\n" ,i);

//  if we use ++i then it first increse the value of variable and then use the value of variable
// printf("%d\n" ,++i);
// printf("%d\n" ,i);

int i=10;

//
// printf("%d\n" ,i++);
// printf("%d\n" ,i);


// printf("%d\n" ,++i);
// printf("%d\n" ,i);
                     //

//
// printf("%d\n" ,i--);
// printf("%d\n",i);

printf("%d\n" ,--i);
printf("%d\n" ,i);
                       //



return 0;

}
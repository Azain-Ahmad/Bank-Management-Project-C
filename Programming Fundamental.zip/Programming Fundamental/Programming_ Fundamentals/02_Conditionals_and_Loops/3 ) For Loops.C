#include<stdio.h>

int main()
{


// USE OF FOR LOOP 
// for (int i = 1;  i <=10; i=i+1)
// {
// printf("My name is AHMAD AKHTAR YOUSAFZAI\n");
// }



// PRINT 100 COUNTING NUMBERS BY USING FOR LOOP

// for (int i=1; i<=100; i=i+1)
// {
//     printf("%d\n" ,i);
// }


// for(int i=10; i>=1; i=i-1)
// {
// printf("%d\n" ,i);
// }


// print the number from 0 to 10 ?
// for(int i=0; i<=10; i=i+1)
// printf("%d\n" ,i);

// LOOP COUNTER CAN BE FLOAT OR EVEN
// for(float i=1.0; i<=5; i=i+1)
// {
//     printf("%.2f\n" ,i);
// }

// print english alphabet a to z
// for(char ch='A'; ch<='Z'; ch++)
// printf("%c\n" ,ch);

for(char ch='A'; ch<='Z'; ch=ch+2)
printf("%c\n" ,ch);

return 0;
}
#include<stdio.h>
int main()
{


// int i=10;

// printf("%d\n" ,i++);
// printf("%d\n" ,i);

// printf("%d\n" ,++i);
// printf("%d\n" ,i);

// printf("%d\n" ,++i);
// printf("%d\n" ,++i);


// printf("%d\n" ,i--);
// printf("%d\n",i);

// printf("%d\n" ,--i);
// printf("%d\n" ,i);


// PRINT THE  NUMBER FROM  TO N IF NUMBE  IS GIVEN BY USER

int n;
printf("Enter the number :");
scanf("%d" ,&n);

// int i=0;
// while(i<=n)
// {
// printf("%d\n" ,i);
// i++;
// ++i;

// i--;
// --i;

// i=i+2;
// }

for(int i=0; i<=5; i++){
if(i<=5)
{
    printf("%d\n" ,i);
}
// else
// {
//     printf("%d" ,i);
// }
}
return 0;

}
#include<stdio.h>
// i-- is pre-DECREMENT  operator : if we use i-- then it first USE the value of variable and then decrease the value of variable
//--i is post-decrement operator : if we use --i then it first decrease  the value of variable and then use the value of variable

int main()
{
int i=1;

//  if we use i-- then it first use  the value of variable and then decrease  the value of variable
// printf("%d\n" ,i--);
// printf("%d\n" ,i);

//  if we use --i then it first decreae  the value of variable and then use the value of variable

printf("%d\n" ,--i);
printf("%d\n" ,i);
return 0;

}
#include<stdio.h>

int main()
{
int i=5;
while(i<=11)
{
    printf("%d\n" ,i);
}
return 0;
}
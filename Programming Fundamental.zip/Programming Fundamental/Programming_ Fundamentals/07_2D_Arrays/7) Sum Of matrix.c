#include <stdio.h>
int main()
{
    int r, c, i, j, sum = 0;
    printf("Enter the value for rows    :");
    scanf("%d", &r);
    printf("Enter the value for columns :");
    scanf("%d", &c);

    printf("Enter All The Elements :\n");

    int arr[r][c];
    for (i = 0; i < r; i++)
    {
        for (j = 0; j < c; j++)
        {
            scanf("%d", &arr[i][j]);
        }
        printf("\n");
    }

    for (i = 0; i < r; i++)
    {
        for (j = 0; j < c; j++)
        {
            printf("%d", arr[i][j]);
        }
        printf("\n");
    }

    for (i = 0; i < r; i++)
    {
        for (j = 0; j < c; j++)
        {
            sum = sum + arr[i][j];
        }
    }
    printf("The Total Sum of Matric Are %d", sum);
}
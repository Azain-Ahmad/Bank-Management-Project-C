# include <stdio.h>
int main ()
{
    int r,c ,i ,j;
    printf("Enter the Number of rows :");
    scanf("%d" ,&r);
    printf("Enter the Number of cols :");
    scanf("%d" ,&c);
    int arr[r][c];
    for(i=0; i<r; i++)
    {
        for(j=0; j<c; j++)
        {
            printf("Element [%d][%d]",i,j);
            scanf("%d" ,&arr[i][j]);
        }
        printf("\n");
    }

    for(i=0; i<r; i++)
    {
        for(j=0; j<c; j++)
        {
            printf("%d" ,arr[i][j]);
        }
        printf("\n");
    }

int max_sum = 0;

int max_row = 0;


    for(i=0; i<r; i++)
    {
        int row_sum = 0;
        for(j=0; j<c; j++)
        {
            row_sum =row_sum  + arr[i][j];
        }
        if(i == 0 || row_sum > max_sum)
        {
            max_sum = row_sum;
            max_row=i;

        }
    }
    printf("The Row %d has Maximum Sum = %d",max_row,max_sum);
    return 0;
}
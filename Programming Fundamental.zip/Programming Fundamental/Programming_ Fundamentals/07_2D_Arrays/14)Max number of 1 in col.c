# include <stdio.h>
int main ()
{
    int r,c ,i ,j;
    printf("Enter the Number of rows :");
    scanf("%d" ,&r);
    printf("Enter the Number of cols :");
    scanf("%d" ,&c);

    int arr[r][c];
    for(i=0; i<r; i++)
    {
        for(j=0; j<c; j++)
        {
            printf("Element [%d][%d] :",i,j);
            scanf("%d" ,&arr[i][j]);
        }
        printf("\n");
    }

    for(i=0; i<r; i++)
    {
        for(j=0; j<c; j++)
        {
            printf("%d" ,arr[i][j]);
        }
        printf("\n");
    }

int max_count = 0;

int max_index = 0;



    for(j=0; j<c; j++)
    {
                int count = 0;

        for(i=0; i<r; i++)
        {
            if(arr[i][j] == 1)
            {
                count ++;
            }
        
        if(max_count < count)
        {
            max_count = count;
            max_index = j;
        }
            
        }
        printf("\n");
    }
    printf("Maximum Number of ones(1) are  %d\n" ,max_count);
    printf("The Maximum Index  of colum is at %d" ,max_index);
    return 0;
}
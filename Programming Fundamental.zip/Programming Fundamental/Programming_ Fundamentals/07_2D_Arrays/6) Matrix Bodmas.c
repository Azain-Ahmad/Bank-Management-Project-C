#include <stdio.h>
int main()
{
    int i, j;
    int a[4][4] = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}, {13, 14, 15, 16}};
    int b[4][4] = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}, {13, 14, 15, 16}};

    // Division of Two MAtrices are
    printf("Division  of Two MAtrices are:\n");

    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 4; j++)
        {
            printf("%d\t", a[i][j] / b[i][j]);
        }
        printf("\n");
    }

    //  Multiplication of Two MAtrices are
    printf("Multiplication of Two MAtrices are:\n");

    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 4; j++)
        {
            printf("%d\t", a[i][j] * b[i][j]);
        }
        printf("\n");
    }

    // Addition of Two MAtrices are
    printf("Addition  of Two MAtrices are:\n");

    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 4; j++)
        {
            printf("%d\t", a[i][j] + b[i][j]);
        }
        printf("\n");
    }
    // Subtraction of Two MAtrices are

    printf("Subtraction  of Two MAtrices are:\n");

    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 4; j++)
        {
            printf("%d\t", a[i][j] - b[i][j]);
        }
        printf("\n");
    }

    return 0;
}
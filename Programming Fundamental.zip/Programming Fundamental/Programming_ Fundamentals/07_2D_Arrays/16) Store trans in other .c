# include <stdio.h>
int main ()
{
    int r,c ,i ,j;
    printf("Enter the Number of rows :");
    scanf("%d" ,&r);
    printf("Enter the Number of cols :");
    scanf("%d" ,&c);

    printf("\n");
    int arr[r][c];
    for(i=0; i<r; i++)
    {
        for(j=0; j<c; j++)
        {
            printf("Element [%d][%d] :",i,j);
            scanf("%d" ,&arr[i][j]);
        }
        printf("\n");
    }

    for(i=0; i<r; i++)
    {
        for(j=0; j<c; j++)
        {
            printf("%d " ,arr[i][j]);
        }
        printf("\n");
    }
    int brr[c][r];
printf("\nTranspose of Matrix is :\n");

    for(i=0; i<c; i++)
    {
        for(j=0; j<r; j++)
        {
            brr[i][j] = arr[j][i];
        }
        printf("\n");
    }



for(i=0; i<c; i++)
    {
        for(j=0; j<r; j++)
        {
            printf("%d " ,brr[i][j]);
        }
        printf("\n");
    }

return 0;
}



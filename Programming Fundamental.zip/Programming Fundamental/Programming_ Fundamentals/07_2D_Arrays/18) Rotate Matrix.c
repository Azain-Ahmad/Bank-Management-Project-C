#include <stdio.h>
int main()
{
    int n, i, j;
    printf("Enter the Number of rows and columns :");
    scanf("%d", &n);

    printf("\n");
    int arr[n][n];

    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            printf("Element [%d][%d] :", i, j);
            scanf("%d", &arr[i][j]);
        }
        printf("\n");
    }

    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            printf("%d ", arr[i][j]);
        }
        printf("\n");
    }

    // Swap The Numbers
    for (i = 0; i < n; i++)
    {
        int j = 0;
        int k = n-1;
        while(j<k)
        {
            int temp = arr[i][j];
            arr[i][j] = arr[i][k];
            arr[i][k] = temp;
            j++;
            k--;
        }
    }

    printf("\n Rotation of Matrix in Clockwise  :\n");
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++) 
        {
            printf("%d ", arr[i][j]);
        }
        printf("\n");
    }

    return 0;
}

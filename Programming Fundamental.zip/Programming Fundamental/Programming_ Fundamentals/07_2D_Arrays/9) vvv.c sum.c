#include <stdio.h>
int main()
{
    int rows, cols, i, j;
    printf("Enter the Number of Rows :");
    scanf("%d", &rows);
    printf("Enter the Number of Coulmns :");
    scanf("%d", &cols);

    int arr[rows][cols];
    // Inut Array Elements from User
    for (i = 0; i < rows; i++)
    {
        for (j = 0; j < cols; j++)
        {
            printf("Elemrnt [%d][%d] :", i, j);
            scanf("%d", &arr[i][j]);
        }
        printf("\n");
    }
    // Printing the number of Elements of array
    for (i = 0; i < rows; i++)
    {
        for (j = 0; j < cols; j++)
        {
            printf("%d ", arr[i][j]);
        }
        printf("\n");
    }

    // SUM of specific portion of 2d array 5 * 5 
    int sum = 0;
    if (rows > 3 && cols > 3) {
        for (i = 2; i <= 3; i++) {
            for (j = 1; j <=3; j++)
            {
                sum += arr[i][j];
            }        
        }
    }
    printf("Sum is %d" ,sum);
    return 0;
}
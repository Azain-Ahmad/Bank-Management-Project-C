#include <stdio.h>
int main()
{
    int i, j;
    int arr[4][2] = {{1, 2}, {3, 4}, {5, 6}, {7, 8}};
    printf("Roll Number\tMarks\n");
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 2; j++)
        {
            printf("%d  \t\t", arr[i][j]);
        }
        printf("\n");
    }
    return 0;
}
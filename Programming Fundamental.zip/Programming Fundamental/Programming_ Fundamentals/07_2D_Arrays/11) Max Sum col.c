# include <stdio.h>
int main ()
{
    int r,c ,i ,j;
    printf("Enter the Number of rows :");
    scanf("%d" ,&r);
    printf("Enter the Number of cols :");
    scanf("%d" ,&c);

    int arr[r][c];
    for(i=0; i<r; i++)
    {
        for(j=0; j<c; j++)
        {
            printf("Element [%d][%d] :",i,j);
            scanf("%d" ,&arr[i][j]);
        }
        printf("\n");
    }

    for(i=0; i<r; i++)
    {
        for(j=0; j<c; j++)
        {
            printf("%d" ,arr[i][j]);
        }
        printf("\n");
    }

int max_sum = 0;

int max_col = 0;



    for(j=0; j<c; j++)
    {
                int col_sum = 0;

        for(i=0; i<r; i++)
        {
            col_sum =col_sum  + arr[i][j];
        }
        if(j == 0 || col_sum > max_sum)
        {
            max_sum = col_sum;
            max_col=j;

        }
    }
    printf("The Column %d has Maximum Sum = %d",max_col,max_sum);
    return 0;
}
#include <stdio.h>

int main() {
    int n, i, j, k;

    printf("Enter the order of the square matrix (n x n): ");
    scanf("%d", &n);

    int a[n][n], result[n][n];

    // Input
    printf("Enter the elements of the matrix:\n");
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            scanf("%d", &a[i][j]);
        }
    }

    // Initialize result matrix
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            result[i][j] = 0;
        }
    }

    // Multiply matrix with itself (A * A)
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            for (k = 0; k < n; k++) {
                result[i][j] += a[i][k] * a[k][j];
            }
        }
    }

    // Output
    printf("The square of the matrix is:\n");
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            printf("%d ", result[i][j]);
        }
        printf("\n");
    }

    return 0;
}

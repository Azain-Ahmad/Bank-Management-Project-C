#include <stdio.h>
int main()
{
    int stdt_no, marks;
    int i, j;
    printf("Enter the Number of Students :");
    scanf("%d", &stdt_no);

    printf("Enter the Marks  of Subjects :");
    scanf("%d", &marks);
    
    int arr[100][3];

    for (i = 0; i < stdt_no; i++)
    {
        for (j = 0; j < marks; j++)
        {
            scanf("%d",&arr[i][j]);
        }
    }
    printf("\n");
    printf("MATHS\tBiology\tChemistry\n");
    for (i = 0; i < stdt_no; i++)
    {
        for (j = 0; j < marks; j++)
        {
            printf("%d\t",arr[i][j]);
        }
        printf("\n");
    }
    return 0;
}
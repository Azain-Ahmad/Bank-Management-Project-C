#include <stdio.h>

int main()
{
    int m, n, p, q;
    int i, j, k;

    // Matrix 1
    printf("Enter the number of rows for matrix 1: ");
    scanf("%d", &m);
    printf("Enter the number of columns for matrix 1: ");
    scanf("%d", &n);

    int a[m][n];
    printf("Enter the Elements of Matrix 1:\n");
    for (i = 0; i < m; i++)
    {
        for (j = 0; j < n; j++)
        {
            printf("Element[%d][%d]: ", i, j);
            scanf("%d", &a[i][j]);
        }
    }

    printf("Elements of Matrix 1 are:\n");
    for (i = 0; i < m; i++)
    {
        for (j = 0; j < n; j++)
        {
            printf("%d ", a[i][j]);
        }
        printf("\n");
    }

    // Matrix 2
    printf("Enter the number of rows for matrix 2: ");
    scanf("%d", &p);
    printf("Enter the number of columns for matrix 2: ");
    scanf("%d", &q);

    int b[p][q];
    // Input the Elements of Matrix 2
    printf("Enter the Elements of Matrix 2:\n");
    for (i = 0; i < p; i++)
    {
        for (j = 0; j < q; j++)
        {
            printf("Element[%d][%d]: ", i, j);
            scanf("%d", &b[i][j]);
        }
    }

    printf("Elements of Matrix 2 are:\n");
    for (i = 0; i < p; i++)
    {
        for (j = 0; j < q; j++)
        {
            printf("%d ", b[i][j]);
        }
        printf("\n");
    }

    // Check condition for multiplication
    if (n != p)
    {
        printf("Matrices cannot be multiplied! Columns of matrix 1 must equal rows of matrix 2.\n");
    }
    else
    {
        int resultant[m][q];

        // Matrix multiplication
        for (i = 0; i < m; i++)
        {
            for (j = 0; j < q; j++)
            {
                resultant[i][j] = 0;
                for (k = 0; k < n; k++)
                {
                    resultant[i][j] += a[i][k] * b[k][j];
                }
            }
        }

        // Output
        printf("The Resultant Multiplication Matrix is given as:\n");
        for (i = 0; i < m; i++)
        {
            for (j = 0; j < q; j++)
            {
                printf("%d ", resultant[i][j]);
            }
            printf("\n");
        }
    }

    return 0;
}

#include <stdio.h>
// int main()
// {
//     int arr[5][5]={{1,1},{2,2},{3,3},{4,4},{5,5}},i,max;
// max = arr[0];
// for(i=1; i<5; i++)
// {
//     if(arr[i] > max)
//     max=arr[i];
// }
// printf("%d" ,max);
//     return 0;
// }
int main()
{
    int r, c, i, j;
    printf("Enter the value for rows    :");
    scanf("%d", &r);
    printf("Enter the value for columns :");
    scanf("%d", &c);

    printf("Enter All The Elements :\n");

    int arr[r][c];
    for (i = 0; i < r; i++)
    {
        for (j = 0; j < c; j++)
        {
            printf("Element [%d][%d]: ", i, j);

            scanf("%d", &arr[i][j]);
        }
        printf("\n");
    }
    
    printf("\nYour Matrix.\n");
    for (i = 0; i < r; i++)
    {
        for (j = 0; j < c; j++)
        {
            printf("%d ",arr[i][j]);

            
        }
        printf("\n");
    }
    
    int max = arr[0][0];
    int max_row = 0, max_col = 0;

    for (i = 0; i < r; i++)
    {
        for (j = 0; j < c; j++)
        {
            if (arr[i][j] > max)
            {
                max = arr[i][j];
                max_row = i;
                max_col = j;
            }
        }
    }

    printf("MAX number is %d at position [%d][%d]\n", max, max_row, max_col);
    return 0;
}
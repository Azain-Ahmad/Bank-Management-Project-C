#include <stdio.h>
int main()
{
    int a[3][2] = {{1, 2}, {3, 4}, {5, 6}};
    int b[2][4] = {{1, 2, 3, 4}, {5, 6, 7, 8}};
    int resultant[3][4];

    int i, j, k;
    int cr = 2; // pehla wala ka row and dusra wala ka colum same hia and
    // Multiplying  Matrix
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 4; j++)
        {
            // i row of a matrix     a[i][0],a[i][1],a[i][2] ........
            // j colum of b matrix   a[0][j],a[1][j],a[2][j] ........

            resultant[i][j] = 0;
            for (k = 0; k < cr; k++)
            {
                resultant[i][j] += a[i][k] * b[k][j];
            }
        }
    }
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 4; j++)
        {
            printf("%d ", resultant[i][j]);
        }
            printf("\n");

    }
    return 0;
}
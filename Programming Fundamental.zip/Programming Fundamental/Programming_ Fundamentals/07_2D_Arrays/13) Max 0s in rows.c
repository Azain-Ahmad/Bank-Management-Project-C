# include <stdio.h>
int main()
{
    int rows,cols ,i,j;
    printf("Enter the number of Rows :");
    scanf("%d" ,&rows);
    printf("Enter the number of Columns  :");
    scanf("%d" ,&cols);
//  input the element of rows and columns from user
    int arr[rows][cols];
    for(i=0; i<rows; i++)
    {
        for(j=0; j<cols; j++)
        {
            printf("Element [%d][%d] :",i,j);
            scanf("%d" ,&arr[i][j]);
        }
        printf("\n");
    }
// Print the Element of rows and columns 
    for(i=0; i<rows; i++)
    {
        for(j=0; j<cols; j++)
        {
            printf("%d" ,arr[i][j]);
        }
        printf("\n");
    }

int max_count = 0;
int max_index= 0;
    for(i=0; i<rows; i++)
    {
        int count = 0;

        for(j=0; j<cols; j++)
        {
            if(arr[i][j] == 0)
            count ++;
           
        }
        if(max_count <count)
        {
            max_count=count;
             max_index = i;
        }
        // printf("\n");
    }
    printf("Maximum Number of zeros(0) are  %d\n" ,max_count);
    printf("The Maximum Index  of row is at %d" ,max_index);
    return 0;
}
# include <stdio.h>
# include <string.h>
int main()
{
    char name[6][25];
    int i;
    puts("Enter any six names :");
    for(i=0; i<6; i++)
    {
        fgets(name[i], sizeof(name[i]),stdin);
    }
        for(i=0; i<6; i++)
    {
        printf("Name %d is %s" ,i+1,name[i]);
    }    
    return 0;
}
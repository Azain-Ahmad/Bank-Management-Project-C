#include <stdio.h>
int main()
// charactor store 1 byte in memory as compare to the integer

//  as we know integer store    >---4---> bytes in memory

{
        char arr[5] = {'A', 'H', 'M', 'A', 'D'};
        printf("%p\n", &arr[0]);
        printf("%p\n", &arr[1]);
        printf("%p\n", &arr[2]);
        printf("%p\n", &arr[3]);
        printf("%p\n", &arr[4]);

        return 0;
}
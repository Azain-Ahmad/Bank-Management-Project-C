# include <stdio.h>
int main()
{
char str[]="College Wallah Is Best Channel For Codders";
int i =0 , count = 0;
while(str[i] != '\0')
{
    count = count + 1;
i++;
}
printf("%d" ,count);
printf("Size of Array is %d" ,sizeof(str));
printf("\nSize of array: %lu", sizeof(str));  // Output: 43

    return 0;
}


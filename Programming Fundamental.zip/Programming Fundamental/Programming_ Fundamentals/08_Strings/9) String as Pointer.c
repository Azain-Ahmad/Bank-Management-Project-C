# include<stdio.h>
# include<string.h>
int main()
{
    char str[]="College Wallah";
    char* ptr = &str[0]; // ptr now points to the  >---str[0]<----

    /*   Both &str[0] and str point to the same memory address — the start 
    of the string "College Wallah". Therefore, the output will be two 
    identical addresses printed in pointer format.
*/
    printf("%p\n" ,&str[0]);
    printf("%p" ,str);
return 0;
}
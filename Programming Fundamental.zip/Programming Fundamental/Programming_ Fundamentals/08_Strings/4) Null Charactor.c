# include <stdio.h>
int main()
{
    // char ch = '\0';
    // printf("%c" ,ch);
    // printf("%d" ,ch);


    int x = 0;
    char a = (char)x;
    printf("%c" ,a); //  /0 not print in program 

    return 0;
}


# include <stdio.h>
int main ()
{
char name[50];
scanf("%s", name);
// gets(name);

printf("%s" ,name);

return 0;
}
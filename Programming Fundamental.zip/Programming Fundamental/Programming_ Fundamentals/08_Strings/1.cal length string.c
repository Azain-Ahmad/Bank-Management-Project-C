#include <stdio.h>
#include <string.h>

int main() {
    char str[100];
    // int i = 0;
    printf("Enter a string: ");
    fgets(str,sizeof(str) ,stdin);  
    // while (str[i] != '\0') {
    //     i++;
    // }
    // printf("Length of the string is: %d\n", i);
    printf("length of string is %llu",strlen(str));
    return 0;
}
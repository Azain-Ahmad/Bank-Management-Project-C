# include <stdio.h>
# include <string.h>
int main()
{
    // char str[]="My name is Ahmad Akhtar";
    // puts(str);

    char str[40];
    printf("Enter the Input of Str:");
    // scanf("%s", str);  // To take input but it show the first word as output 
    // scanf("%[^\n]s", str); // when we take input it show the  complete sentense of string
    
    scanf("%[^\n]s" ,str);
    printf("Your Output Is %s" ,str);



    return 0;
}
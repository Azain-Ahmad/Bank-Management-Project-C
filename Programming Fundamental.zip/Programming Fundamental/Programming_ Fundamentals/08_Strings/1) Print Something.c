# include <stdio.h>
int main()
{
    char arr[5]={'A','H','M','A','D'};
    printf("%c%c%c%c%c" ,arr[0], arr[1] ,arr[2] ,arr[3] ,arr[4]);
    return 0;
}
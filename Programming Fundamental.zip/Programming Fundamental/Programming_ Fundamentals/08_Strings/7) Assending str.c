#include <stdio.h>
#include <string.h>

int main() {
    char name[6][25], temp[25];
    int i, j;

    puts("Enter any six names:");
    for(i = 0; i < 6; i++) {
        fgets(name[i], sizeof(name[i]), stdin);
        // name[i][strcspn(name[i], "\n")] = '\0';  // Remove newline character
        fflush(stdin);
    }

    // Sorting in ascending order
    for(i = 0; i < 6; i++) {
        for(j = i + 1; j < 6; j++) {
            if(strcmp(name[i], name[j]) > 0) {
                strcpy(temp, name[i]);
                strcpy(name[i], name[j]);
                strcpy(name[j], temp);
            }
        }
    }

    printf("\nThe Ascending Order of Names is:\n");
    for(i = 0; i < 6; i++) {
        printf("%s\n", name[i]);
    }

    return 0;
}

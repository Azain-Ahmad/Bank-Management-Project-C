# include <stdio.h>
# include <string.h>
int main()
{
    char str[100];
    int i=0 ,count = 0;
    printf("Enter Any Sentense");
    fgets(str,sizeof(str),stdin);
    
    while(str[i] != '\0')
    // for(i=0;str[i] != '\0'; i++)
    {

    if(str[i] == 'a' || str[i] == 'A'||  
        str[i] == 'e' || str[i] == 'E'||  
        str[i] == 'i' || str[i] == 'I'||  
        str[i] == 'o' || str[i] == 'O'||  
        str[i] == 'u' || str[i] == 'U')
        {
        count ++;
        }
        i++;
    }
        printf("%d" ,count);
        return 0;
    
    }
# include <stdio.h>
int main()
{
char str[]="Physics Wallah";
str[0]='M';
str[1]=97;    // Modify the individual charactor 
int i = 0;
while(str[i] !='\0' )
{

    // We can use all the cases in the string to print the output 
printf("%c" ,str[i]);
printf("%c" ,i[str]);   
printf("%c\n" ,*(str+i));
printf("%c\n" ,*(i+str));
i++;
}


    return 0;
}


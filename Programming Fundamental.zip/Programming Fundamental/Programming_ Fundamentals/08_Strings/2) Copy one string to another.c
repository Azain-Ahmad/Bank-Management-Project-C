# include <stdio.h>
# include<string.h>

int main()
{
	char src[100] = "Sir Mazhar";
	char dest[100];
	strcpy(dest ,src);
	printf("Destination is : %s" ,dest);
    // puts(dest);
	return 0;
}

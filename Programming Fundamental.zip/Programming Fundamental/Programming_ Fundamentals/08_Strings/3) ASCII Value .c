# include <stdio.h>
int main()
{
    char ch ='A';
    int x = (int)ch;
    printf("%d" ,x);
    return 0;
}

//     A = 65
//     a = 97
//     charactor of 0 =48
//     charactor of 9 =57
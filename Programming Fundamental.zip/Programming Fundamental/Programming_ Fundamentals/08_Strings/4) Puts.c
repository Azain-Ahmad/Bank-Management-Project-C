# include <stdio.h>
int main ()
{
char name[] = "Ahmad";

puts(name); 

// printf("%s\n", name); 
return 0;
}
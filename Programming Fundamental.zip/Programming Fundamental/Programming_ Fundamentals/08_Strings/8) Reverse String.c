# include <stdio.h>
# include <string.h>

int main()
{
    int size = 0 , k = 0 ;
    char str[100];
    puts("Enter a string :");
    scanf(" %[^\n]s" ,str);

    while(str[k] != '\0')
    {
        size++;
        k++;
    }
    int i ,j;
    j=size-1;
    for(i=0; i<=j; i++ ,j--)
    {
            char temp = str[i];
            str[i] = str[j];
            str [j] = temp;
        
    }
    puts("The Reverse is :");
    puts(str);
return 0;
}

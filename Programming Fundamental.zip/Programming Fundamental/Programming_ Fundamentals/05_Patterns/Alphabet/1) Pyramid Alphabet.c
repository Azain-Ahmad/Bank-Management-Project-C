#include <stdio.h>

int main() {
    int i, j;
    for(i=1; i<=5; i++) {
        for(j=1; j<=9; j++) {  // Need 9 columns for full pyramid width
            if(j >= 6-i && j <= 4+i)  // Condition for centered pyramid
                printf(" B");
            else
                printf("  ");
        }
        printf("\n");
    }
    return 0;
}
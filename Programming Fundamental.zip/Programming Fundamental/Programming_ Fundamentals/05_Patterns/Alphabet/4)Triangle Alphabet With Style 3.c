# include <stdio.h>
// ABCDE ABCD ABC AB A
int main()
{
    int i,j;
    for(i=1; i<=5; i++)
    {
        for(j=1; j<=5; j++)
        {
            if(j<=6 - i)
            {
        printf("%c" ,64 + j);
        }
    
        else
        printf(" ");
        }
        printf("\n");
    }
    return 0;
}
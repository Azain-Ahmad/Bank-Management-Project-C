#include<stdio.h>
///////////     Print inverted star triangle of 5

int main(){
    int i,j;
    for(i=1; i<=5; i++){
        for(j=1; j<=5+1-i; j++){
            printf("*");
        }
        printf("\n");
    }
    return 0;

}


/////////////     Print inverted star triangle of n number 

// int main(){
//     int num, i,j;
//     printf("Enter the number :");
//     scanf("%d" ,&num);
//     for(i=1; i<=num; i++){
//         for(j=1; j<=num+1-i; j++){
//             printf("*");
//         }
//         printf("\n");
//     }
//     return 0;
// }

/////////////     Print inverted star triangle of n number 


int main(){
    int i,j,num,a;
    
    printf("Enter the number :");
    scanf("%d" ,&num);
    a=num;
    for(i=1; i<=num; i++){
        for(j=1; j<=a; j++){
            printf("*");
        }
        a--;
        printf("\n");
    }
    return 0;
}





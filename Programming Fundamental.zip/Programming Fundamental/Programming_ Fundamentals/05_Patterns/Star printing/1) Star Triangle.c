#include<stdio.h>
//////////////////////   Print Star Triangle of 5 

// int main(){
//     int i,j;
//     for(i=1; i<=5; i++){
//         for(j=1; j<=i; j++){
//             printf("*");
//         }
//         printf("\n");
//     }
//         return 0;
// }


//////////////////////   Print Star of n number 

int main(){
    int num, i,j;
    printf("Enter the Number :");
    scanf("%d" ,&num);
    for(i=1; i<=num; i++){
        for(j=1; j<=i; j++){
            printf("*");
        }
        printf("\n");
    }
        return 0;
}


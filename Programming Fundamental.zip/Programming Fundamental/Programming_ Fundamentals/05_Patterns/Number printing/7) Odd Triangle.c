#include<stdio.h>
////////////////////   print odd number from i to n 
 int main(){
     int num ,i;
     printf("Enter the number :");
     scanf("%d" ,&num);
     for(i=1; i<=2 * num-1; i+=2) // For print of odd numbe rwe use this (2*n-1)
     {
         printf("%d\t" ,i);
     }
     return 0;
 }



//////////////////////   print odd number from i to n  other method by other variable 

// int main(){
//     int num ,i,a=1;
//     printf("Enter the number :");
//     scanf("%d" ,&num);

//     for(i=1; i<=num; i++)
//     {
//         printf("%d\t" ,a);
//         a=a+2;
//     }
//     return 0;
// }

///////  we cannot find directly odd number triangle dirrectly so we can add another variable 

// int main()
// {
//     int i,j,a;
//     for(i=1; i<=5; i++)
//     {
//         a=1;
//         for(j=1; j<=i; j++)
//         {
//         printf("%d\t" ,a);
//         a+=2;
//         }
//         printf("\n");
//     }
//     return 0;
// }



///////////////////////////  Print odd Number triangle good method 
//int main()
//{
//    int num,i,j,a;
//    printf("Enter the number: ");
//    scanf("%d", &num);
//    for(i=1; i<=num; i++)
//    {
//        a=1;
//        for(j=1; j<=i; j++)
//        {
//        printf("%d" ,a);
//        a+=2;
//        }
//        printf("\n");
//    }
//    return 0;
//}
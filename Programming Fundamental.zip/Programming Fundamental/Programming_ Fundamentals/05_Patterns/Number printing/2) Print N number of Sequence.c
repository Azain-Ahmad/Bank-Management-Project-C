#include<stdio.h>
//////////////  Print Square of 5 * 5

// int main(){
//     int i,j;
//     for(i=1; i<=5; i++){
//         for(j=1; j<=5; j++){
//             printf("*");
//         }
//         printf("\n");
//     }
// }

//////////////  Print Square of n number by Asking from user 

// int main(){
//     int num,i,j;
//     printf("Enter the Number :");
//     scanf("%d" ,&num);
//     for(i=1; i<=num; i++){
//         for(j=1; j<=num; j++){
//             printf("*");
//         }
//         printf("\n");
//     }
// }


//////////////  Print Number Square of n number by Asking from user 

int main(){
    int num,i,j;
    printf("Enter the Number :");
    scanf("%d" ,&num);
    for(i=1; i<=num; i++){
        for(j=1; j<=num; j++){
            printf("%d" ,j);
        }
        printf("\n");
    }
}




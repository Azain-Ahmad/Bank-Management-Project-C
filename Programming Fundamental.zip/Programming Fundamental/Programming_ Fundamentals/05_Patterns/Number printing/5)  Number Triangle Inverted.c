# include<stdio.h>
/////////////// Print Nnumber  Triangle   Inverted from 1 to 5 

// int main()
// {
//     int i,j;
//     for(i=1; i<=5; i++)
//     {
//         for(j=1; j<=5+1-i; j++)
//         {
//             printf("%d" ,j);
//         }
//         printf("\n");
//     }
//     return 0;
// }


/////////////// Print Nnumber  Triangle   Inverted 
int main()
{
    int num,i,j;
    printf("Enter the number :");
    scanf("%d" ,&num);
    for(i=1; i<=num; i++)
    {
        for(j=1; j<=num+1-i; j++)
        {
            printf("%d" ,j);
        }
        printf("\n");
    }
    return 0;
}
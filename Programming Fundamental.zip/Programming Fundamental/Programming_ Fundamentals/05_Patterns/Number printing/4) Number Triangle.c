#include<stdio.h>
////////////////////  Number triangle from 1 to 5 

// int main(){
//     int i,j;
//     for(i=1; i<=5; i++)
//     {
//         for(j=1; j<=i; j++)
//         {
//             printf("%d" ,j);
//         }
//         printf("\n");
//     }
//     return 0;
// }


////////////////////  Number triangle from 1 to 5 
int main(){
    int num, i,j;
    printf("Enter the number :");
    scanf("%d" ,&num);
    for(i=1; i<=num; i++)
    {
        for(j=1; j<=i; j++)
        {
            printf("%d" ,j);
        }
        printf("\n");
    }
    return 0;
}
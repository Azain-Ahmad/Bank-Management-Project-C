# include<stdio.h>
// int main(){
//     int num,i,j;
//     printf("Enter the number :");
//     scanf("%d" ,&num);
//     for(i=1; i<=num; i++)
//     { int a=1;
//         for(j=1; j<=num; j++)
//     {
//         printf("%d" ,a);
//         a=a+2;
//     }
//     printf("\n");
//     }
// return 0;
// }


 #include<stdio.h>
 int main() {
     int num, i, j;
     printf("Enter the number: ");
     scanf("%d", &num);
    
     for (i = 1; i <= num; i++) {
         for (j = 1; j <= num; j++) {
             printf("%d ", 2 * (j - 1) + 1);  // Directly calculate odd numbers
       }
        printf("\n");
     }
    
     return 0;
 } 





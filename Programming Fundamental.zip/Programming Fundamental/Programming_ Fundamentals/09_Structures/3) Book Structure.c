#include <stdio.h>
int main()
{
    struct book
    {
        char name[25];
        float price;
        int pages_no;
    } book1;

    printf("Enter the name of book 1 :");
    scanf("%s", book1.name);

    printf("Enter the Price of book 1 :");
    scanf("%f", &book1.price);

    printf("Enter the Number of pages of book 1 :");
    scanf("%d", &book1.pages_no);
    printf("\n");

    printf("Following are the attributes of book 1 :\n");
    printf("The name of book 1 is %s\n", book1.name);
    printf("The Price of book 1 is %.2f\n", book1.price);
    printf("The numberof pages book 1 is %d\n", book1.pages_no);

    return 0;
}
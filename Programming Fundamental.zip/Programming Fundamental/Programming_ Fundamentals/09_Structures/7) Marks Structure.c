# include <stdio.h>
struct student
{
    int rn;
    char name[50];
    float s1,s2,s3,percentage;
};
int main()
{
    struct student std;

    printf("Ener the Roll Number :");
scanf("%d" ,&std.rn);

printf("Please Enter the name :");
gets(std.name);

printf("Enter Marks fOR three Subjects :\n");
scanf("%f" ,& std.s1);
scanf("%f" ,& std.s2);
scanf("%f" ,& std.s3);
std.percentage = (())

}

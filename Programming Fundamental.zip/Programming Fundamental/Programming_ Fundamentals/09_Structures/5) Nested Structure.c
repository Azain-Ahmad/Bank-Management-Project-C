#include <stdio.h>

int main()
{
    struct Hotel
    {
        char address[50];
        int flat_no;
    };

    struct Person
    {
        char name[50];
        struct Hotel x;
    } P;

    printf("Enter the name of person: ");
    fflush(stdin); // Clear input buffer (compiler dependent)
    fgets(P.name, sizeof(P.name), stdin);

    printf("Enter the address of hotel: ");
    fflush(stdin); // Clear buffer again before next fgets
    fgets(P.x.address, sizeof(P.x.address), stdin);

    printf("Enter the Flat Number of Hotel: ");
    scanf("%d", &P.x.flat_no);

    printf("\nPerson Name: %s", P.name);
    printf("Hotel Address: %s", P.x.address);
    printf("Hotel Flat No: %d\n", P.x.flat_no);

    return 0;
}

# include <stdio.h>
# include <string.h>
struct student
{
    int roll_no;
    char name[50];
    float cgpa;
};
int main()
{
struct student std;
printf("Ener the Roll Number :");
scanf("%d" ,&std.roll_no);

printf("Please Enter the name :");
// scanf("%s" ,&std.name);
fgets(std.name ,sizeof(std.name) ,stdin);

printf("Ener the CGPA :");
scanf("%f" ,&std.cgpa);
printf("Roll Number\t\tName\t\tCGPA\n");
printf("Roll Number is %d\tName is %s\tCgpa is %.3f",std.roll_no,std.name,std.cgpa);

return 0;
}
#include <stdio.h>

int main() // it should be main(), not man()
{
    // Declare a structure for pokemon
    struct pokemon
    {
        int hp;
        int speed;
        int attack;
        char tier;
    };

    // Create a variable of type pokemon for pikachu
    struct pokemon pikachu;
    pikachu.hp = 100;
    pikachu.speed = 100;
    pikachu.attack = 100;
    pikachu.tier = 'A';

    // Create another variable for charizard
    struct pokemon charizard;
    charizard.hp = 90;
    charizard.speed = 80;
    charizard.attack = 70;
    charizard.tier = 'C';

    // Correct way to print a character is using %c
    printf("%c", charizard.tier);

    return 0;
}

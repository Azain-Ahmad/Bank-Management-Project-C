#include <stdio.h>

int main() // it should be main(), not man()
{
    // Declare a structure for pokemon
    struct pokemon
    {
        int hp;
        int speed;
        int attack;
        char tier;
    }pikachu ,charizard;

    pikachu.hp = 100;
    pikachu.speed = 100;
    pikachu.attack = 100;
    pikachu.tier = 'A';

    charizard.hp = 90;
    charizard.speed = 80;
    charizard.attack = 70;
    charizard.tier = 'C';

    printf("The Tier of Pikachu is %c\n", pikachu.tier);

    printf( "The Tier of Charizard is %c\n", charizard.tier);

    return 0;
}

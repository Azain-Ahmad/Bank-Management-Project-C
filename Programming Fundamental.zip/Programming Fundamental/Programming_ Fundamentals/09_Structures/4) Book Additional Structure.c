#include <stdio.h>
#include <string.h>
int main()
{
    struct book
    {
        char name[25];
        float price;
        int pages_no;
    } a, b, c;

    strcpy(a.name, "Programming Fundamental");
    a.price = 1500;
    a.pages_no = 1000;

    strcpy(b.name, "Computer Networking");
    b.price = 1000;
    b.pages_no = 800;

    strcpy(c.name, "Applied Physics");
    c.price = 700;
    c.pages_no = 560;

    printf("Book 1 Attributes are :\n");
    printf("Name is %s\tPrice is %.2f\tNumber of pages are %d\n", a.name, a.price, a.pages_no);

    printf("Book 2 Attributes are :\n");
    printf("Name is %s\tPrice is %.2f\tNumber of pages are %d\n", b.name, b.price, b.pages_no);

    printf("Book 3 Attributes are :\n");
    printf("Name is %s\tPrice is %.2f\tNumber of pages are %d\n", c.name, c.price, c.pages_no);

    return 0;
}
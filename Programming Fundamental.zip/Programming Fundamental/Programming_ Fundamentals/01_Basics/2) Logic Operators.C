#include<stdio.h>

int main()
{
    // we use this for && (and) operator
    printf("%d\n" , 4<3 && 4>3);

    // fOR OR operator we use ||
    printf("%d\n" , 5<3 || 5>3);

    // for NOT operator we use ! : it reverse the result like not gate 

    printf("%d\n" , !( 10>5));
    printf("%d\n" ,!(4>10) && (5>2));
    printf("%d\n" ,!(4>10) || !(5>2));
    printf("%d\n", 4*5/2 >8*2/4);



}

#include <stdio.h>

int main() {
    float num1, num2, product;

    // Prompt user for input
    printf("Enter first number: ");
    scanf("%f", &num1);
    printf("Enter second number: ");
    scanf("%f", &num2);

    // Calculate product
    product = num1 * num2;

    // Display result
    printf("The product of %.2f and %.2f is %.2f\n", num1, num2, product);

    return 0;
}

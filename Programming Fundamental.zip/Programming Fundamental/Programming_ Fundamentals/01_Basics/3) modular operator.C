#include<stdio.h>
#include<math.h>
int main()
{
    printf("the remainder is %i\n" , 26%4);
    printf("the answer of  int is %i\n",2*2);
    printf("the answer of float is %.2f\n",4*4.0);
    printf("the answer of float is %.2f\n",4.0*4.0);

    printf("the answer of float is %.2f\n",2.0/3);
    printf("the answer of integer is %i\n",2/3);



    return 0;
}
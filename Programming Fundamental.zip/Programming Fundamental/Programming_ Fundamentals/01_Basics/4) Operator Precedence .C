#include<stdio.h>
int main()
{
    int a=4+9*10;
    printf("%d\n" ,a);
// same precedence the we use associative rule in which we move from left to right to solve our problems in which operation
// is used
    int b =4*3/6*2;
    printf("%d\n" ,b);

    int c=5*2-2*3;
    printf("%d\n",c);

    int d=5*2/2*3;
    printf("%d\n" ,d);

    int e=5*(2/2)*3;
    printf("%d\n " ,e);

    int g=5+2/2*3;
    printf("%d \n",g);

    return 0;
}
#include<stdio.h>

int main()
{
    printf("%d\n" ,4==4);
    printf("%d\n" ,4==3);
    
    printf("%d\n" ,3<4);
    printf("%d\n" ,3>4);
    printf("%d\n" ,4>=3);
    printf("%d\n" ,4<=3);
    NOT EQUAL TO 

    printf("%d\n" ,3!=4);
    printf("%d\n" ,5!=5);

    printf("%d \n", 5==6);
    return 0;
    
}
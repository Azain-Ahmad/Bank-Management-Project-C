#include<stdio.h>

int main()
{
// float num1, num2, product;

//     // Prompt user for input
//     printf("Enter first number: ");
//     scanf("%f", &num1);
//     printf("Enter second number: ");
//     scanf("%f", &num2);

//     // Calculate product
//     product = num1 * num2;

//     // Display result
//     printf("The product of %.2f and %.2f is %.2f\n", num1, num2, product);



int num;
printf("Enter the number :");
scanf("%d",&num);

if(num > 0)
{
    printf("It is a Natural Number\n");
}
else if (num < 0)
{
    printf("It is a Negative Number\n");
}

if(num % 2 != 0)
{
    printf("It is an Odd number\n");
}
else if(num % 2 == 0 && num !=0)
{
    printf("It is an Even number\n");
}
else
{
    printf("It is Zero\n");
}



    return 0;
    }
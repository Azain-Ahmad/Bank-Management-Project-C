#include<stdio.h>
#include<math.h>

int main()
{
    int b,c;
    
    printf("enter the power  : \n");
    scanf("%d%d",&b,&c);
        int power=pow(b,c); 
    printf("The result of %d%d is %d :\n" ,b,c,power);
    

    return 0;
}

// types of conversion 

// #include<stdio.h>
// #include<math.h>

// int main()
// {
//         int a=1.99999999;
//     printf("%i \n" ,a);
//     int b=(int)1.999;
//     printf("%d \n" ,b);
//     return 0;
//     #include<stdio.h>


// }



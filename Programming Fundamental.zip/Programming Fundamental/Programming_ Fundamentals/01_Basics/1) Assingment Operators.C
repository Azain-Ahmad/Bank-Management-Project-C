#include<stdio.h>
int main()
{
    // int a=5 , b=5;
    // a=a+b;
    // printf("%d\n" ,a,b,a);
    
    
    // // when two same variable is used then we use assingment operators like += , -= ,*= ,/= etc
    // int c=5,d=5;
    // c+=d;
    // printf("%d\n",c);

    int e=5,f=5;
    e=e-f;
    printf("%d\n" ,e,f,e);


    int g=5, h=5;
    g-=h;
    printf("%d\n" ,g);

    return 0;

}
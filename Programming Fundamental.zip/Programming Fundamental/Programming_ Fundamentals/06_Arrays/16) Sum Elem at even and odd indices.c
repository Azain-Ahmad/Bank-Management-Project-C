# include <stdio.h>
int main()
{
int arr[10]={1,2,3,4,5,6,7,8,9,10};
int i,Even = 0, Odd = 0;

for(i=0; i<=9; i++)
{
    if(i % 2 == 0)
    {
    Even = arr[i] + Even;
    }
    else
    {
    Odd = arr[i] +Odd;
    }
}
printf("%d" ,Even-Odd);
return 0;
}

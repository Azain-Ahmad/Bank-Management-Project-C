# include <stdio.h>
int main()
{
    int arr[5]={1,2,3,4,5,};
    printf("%d\n" ,arr[0]);

    arr[4]=100;//// Updation in arrays 
        printf("%d\n" ,arr[4]);

float arr_j[6]={1.1,1.2,1.3,1.4,1.5,1.6};
    printf("%.2f" ,arr_j[0]);

    return 0;
}
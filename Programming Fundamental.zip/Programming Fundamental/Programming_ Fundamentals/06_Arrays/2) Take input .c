# include <stdio.h>
int main()
{
    int arr[5] ,i;
    printf("The Elements of Arrays are :\n");
    for(i=0; i<5; i++)
    {
    printf("Enter the %d element of Array:" ,i+1);
    scanf("%d",&arr[i]);
    }
    printf("\n");
    for(i=0; i<5; i++)
    {
    printf("%d",arr[i]);
    }

    return 0;
}
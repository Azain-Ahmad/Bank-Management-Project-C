# include <stdio.h>
int main()
{
    int arr[5] = {1,2,3,4,5} ,i ,sum=0;
    for(i=0; i<=4; i++)
    {
        sum = sum +arr[i];
    }
    printf("The sum is %d" ,sum);

    return 0;
}


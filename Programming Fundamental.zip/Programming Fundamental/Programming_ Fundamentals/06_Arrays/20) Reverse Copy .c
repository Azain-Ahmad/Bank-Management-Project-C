# include <stdio.h>
// int main()
// {
//     int arr[7]={1,2,3,4,5,6,7},i;
//     int brr[7];
// for(i=0; i<7; i++)
// {
// brr[i] =arr[6 - i];
// }
// printf("The reverse of array is");
// for(i=0; i<7; i++)
// {
// printf(" %d", brr[i]);
// }
//     return 0;
// }



// int main()
// {
//     int arr[7] = {1,2,3,4,5,6,7};
//     int i , j ,temp;
//     for(i=2 ,j=5; i<=j; i++ ,j--)
//     {
//         temp = arr[i];
//         arr[i]= arr[j];
//         arr[j]=temp;
//     }
//     for(i=0; i<7; i++)
//     {
//         printf("%d " ,arr[i]);
//     }
//     return 0;
// }



void reverse(int arr[],int n);
int main()
{
    int n,i;
    printf("Enter the elements of arrays :");
scanf("%d" ,&n);

    int arr[n];
    for(i = 0; i < n; i++) {
    printf("Enter element %d: ", i+1);
    scanf("%d", &arr[i]);
}

    reverse(arr,n);
    printf("The reverse array is :");
    for(i=0; i<n; i++)
    {
        printf("%d " ,arr[i]);

    }
    return 0;
}
void reverse(int arr[] ,int n)
{
    int i = 0;
    int j =n-1;
    while(i<j)
    {
        int temp = arr[i];
        arr[i] =arr[j];
        arr[j] = temp;
        i++;
        j--;
    }
return;
}

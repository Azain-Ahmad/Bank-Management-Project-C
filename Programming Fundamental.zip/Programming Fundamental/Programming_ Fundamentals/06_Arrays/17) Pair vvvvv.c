# include <stdio.h>
int main()
{
    int arr[8] = {1,2,3,4,5,6,7,8};
    int i , j ,Total_Pairs = 0;
    int num;
    printf("Enter the number :");
    scanf("%d" ,& num);
    for(i=0; i<=7; i++)
    {
        for(j=i+1; j<=7; j++)
        {
            if(arr[i] + arr[j] == num )
            {
                Total_Pairs++;
                printf("(%d ,%d)\n" ,arr[i] ,arr[j]);
            }
        }
    }
    printf("The Total Number of Pairs are %d" ,Total_Pairs);

return 0;
}

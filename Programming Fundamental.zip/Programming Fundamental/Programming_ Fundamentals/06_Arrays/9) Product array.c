# include <stdio.h>
int main()
{
    int arr[5] = {1,2,3,4,5} ,i ,product =1;
    for(i=0; i<5; i++)
    {
        product = product * arr[i];
    }
    printf("The product is %d" ,product);

    return 0;
}


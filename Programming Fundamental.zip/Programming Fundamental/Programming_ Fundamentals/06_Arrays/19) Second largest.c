# include <stdio.h>
# include <limits.h>
int main()
{
    int arr[7]={1,2,3,4,5,6,7},i;
    int max =INT_MIN;
    int sec_max =INT_MIN;
for(i=0; i<7; i++)
{
    if(arr[i] > max)
    {
    sec_max= max; // sec_max is now previous maximum
    max=arr[i];    //  maximum is now a new maximum
    }
}
// else if(arr[i] > sec_max && max != arr[i])
// sec_max =arr[i];
// }
printf("The Second Maximum Number is %d" ,sec_max);
return 0;
}
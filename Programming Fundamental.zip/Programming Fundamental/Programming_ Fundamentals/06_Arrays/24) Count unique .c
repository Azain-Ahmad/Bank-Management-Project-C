#include <stdio.h>

int main() {
    int arr[100], n, i, j, count;

    // Input array size
    printf("Enter the size of the array: ");
    scanf("%d", &n);

    // Input array elements
    printf("Enter %d elements:\n", n);
    for(i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    printf("Unique elements in the array are: ");
    for(i = 0; i < n; i++) {
        count = 0;

        // Check if arr[i] is equal to any other element
        for(j = 0; j < n; j++) {
            if(i != j && arr[i] == arr[j]) {
                count++;
                break; // not unique, no need to check further
            }
        }

        
        if(count == 0) {
            printf("%d ", arr[i]);
        }
    }


    printf("\n");
    return 0;
}

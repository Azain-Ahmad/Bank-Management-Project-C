# include <stdio.h>
int main()
{
    int arr[5]={1,2,3,4,5},i,max,min;
max = arr[0];
min = arr[0];

int max_ind=arr[0];
int min_ind=arr[0];
for(i=1; i<5; i++)

{
    if(arr[i] > max)
    {
    max=arr[i];
    max_ind = i;
    }
}

for(i=1; i<5; i++)
{
    if(arr[i] < min)
    {
    min=arr[i];
    min_ind = i;
    }
}

printf("Maximum Element is %d\n" ,max);
printf("Minimum Element is %d\n" ,min);


for(i=0; i<5; i++)
{
    int tem = arr[max_ind];
    arr[max_ind] =arr[min_ind];
    arr[min_ind] = tem;
}

for(i=0; i<5; i++)
{
    printf(" %d" ,arr[i]);

}

    return 0;
}
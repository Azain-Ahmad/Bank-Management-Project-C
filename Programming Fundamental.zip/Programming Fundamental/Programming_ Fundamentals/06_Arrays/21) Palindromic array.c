#include <stdio.h>

int main() {
    int arr[7] = {1, 2, 3, 4, 3, 2, 1};
    int i, isPalindrome = 1;

    for (i = 0; i < 7 / 2; i++) {
        if (arr[i] != arr[6 - i]) {
            isPalindrome = 0;
            break;
        }
    }

    // Output result
    if (isPalindrome == 1) {
        printf("The array is a palindrome.\n");
    } else {
        printf("The array is not a palindrome.\n");
    }

    return 0;
}

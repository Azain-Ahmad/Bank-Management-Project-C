# include <stdio.h>
int main()
{
    int arr[5], i;
    for(i=0; i<=4; i++)
    {
        printf("Enter the %d element of array :" ,i+1);
        scanf("%d" ,&arr[i]);
    }

    for(i=4; i>=0; i--)
    {
        printf("%d" ,arr[i]);
    }
    
return 0;
}
# include <stdio.h>
# include <limits.h>
// int main()
// {
//     int arr[5]={1,2,3,4,5,},i,max;
// max = INT_MAX;
// for(i=1; i<5; i++)
// {
//     if(arr[i] > max)
//     max=arr[i];
// }
// printf("%d" ,max);
//     return 0;
// }


int main()
{
    int arr[5]={1,2,3,4,5,},i,min;
min = INT_MIN;
for(i=1; i<5; i++)
{
    if(arr[i] < min)
    min=arr[i];
}
printf("%d" ,min);
    return 0;
}





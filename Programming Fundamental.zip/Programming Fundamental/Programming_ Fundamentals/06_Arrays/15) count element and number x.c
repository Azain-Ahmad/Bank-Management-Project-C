# include <stdio.h>
int main()
{
    int num, i ,found = 0;;
    int arr[9]={1,2,3,4,5,6,7,8,9};
    printf("Enter the number :");
    scanf("%d",&num);

for(i=0; i<9; i++)
{
        if(arr[i] == num)
        {
        printf("Match is found at %d position\n" ,i+1);
        found =1;
        break;
        }
    }
    if (found == 0)
    {
        printf("Match is not Found ");
    }
    else
        printf("The match number is %d" ,arr[i]);

    return 0;
}
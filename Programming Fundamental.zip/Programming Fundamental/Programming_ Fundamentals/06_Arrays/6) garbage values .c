# include <stdio.h>
int main()
{
int arr[5]={123};
printf("%d" ,arr[0]); /// in this garbage value is stored 
return 0;
}
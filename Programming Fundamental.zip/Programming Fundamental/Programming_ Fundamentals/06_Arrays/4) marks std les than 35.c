# include <stdio.h>
int main()
{
    int marks[10] ,i;
    printf("Please Enter The Marks Of 10 Stuents :\n");
    for(i=0; i<=9; i++)
    {
        printf("Enter The Marks of Student %d :",i+1);
        scanf("%d" ,&marks[i]);
    }
    for(i=0; i<=9; i++)
    {
        if(marks[i]<= 35)
        {
        printf("%d\n" ,i);
        }
    }


    return 0;
}
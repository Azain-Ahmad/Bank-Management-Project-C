# include <stdio.h>
int main()
{
    int arr[8] = {1,2,3,4,5,6,7,8};
    int i , j ,k,Total_Triplets = 0;
    int num;
    printf("Enter the number :");
    scanf("%d" ,& num);
    for(i=0; i<=7; i++)
    {
        for(j=i+1; j<=7; j++)
        {
            for(k=j+1; k<=7; k++)
            if(arr[i] + arr[j] +arr[k] == num )
            {
                Total_Triplets++;
                printf("(%d ,%d ,%d)\n" ,arr[i] ,arr[j] ,arr[k]);
            }
        }
    }
    printf("The Total Number of Triplets are %d" ,Total_Triplets);

return 0;
}

#include <stdio.h>

int main() {
    int arr[100], n, i, j, count = 0;
    int visited[100] = {0}; // To mark counted duplicates

    // Input array size
    printf("Enter the size of the array: ");
    scanf("%d", &n);

    // Input array elements
    printf("Enter %d elements:\n", n);
    for(i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    // Count distinct duplicates
    for(i = 0; i < n; i++) {
        if(visited[i] == 1)
            break;

        for(j = i + 1; j < n; j++) {
            if(arr[i] == arr[j]) {
                count++;
                visited[j] = 1; // Mark all duplicates of arr[i]
            }
        }
    }

    printf("Total number of duplicate elements = %d\n", count);
    return 0;
}

#include <stdio.h>
void decreasing(int n);

int main()
{
    int num;
    printf("Enter the Number :");
    scanf("%d", &num);
    decreasing(num);
    return 0;
}
void decreasing(int n)
{
    if (n == 0)
    {
        return;
    }
    else
    {
        printf("%d\n",n);
        return decreasing(n-1);
    }
}

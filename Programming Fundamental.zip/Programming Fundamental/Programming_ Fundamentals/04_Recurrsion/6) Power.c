#include <stdio.h>
int power(int x, int y);
int main()
{
    int a, b;
    printf("Enter the value of a :");
    scanf("%d", &a);

    printf("Enter the value of b :");
    scanf("%d", &b);

    int p = power(a, b);
    printf("%d raised to  the power %d = %d", a, b, p);
    return 0;
}
int power(int x, int y)
{
    if (y == 0)
    {
        return 1;
    }
    else
    {
        int Rec_Ans = x * power(x, y - 1);
        return Rec_Ans;
    }
}

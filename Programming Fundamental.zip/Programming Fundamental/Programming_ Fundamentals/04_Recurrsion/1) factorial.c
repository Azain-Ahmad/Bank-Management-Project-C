# include <stdio.h>
int factorial(int n);

    int main ()
    {
        int num;
        printf("Enter the Number :");
        scanf("%d" ,&num);
        int result = factorial(num);
        printf("Factorial of  number is %d" ,result);
        return 0;
    }
    int factorial(int n)
    {
        if(n == 1)
        {
            return 1;
        }
        else
        {
            int Rec_Ans = n * factorial(n-1);
            return Rec_Ans;

        }
    }


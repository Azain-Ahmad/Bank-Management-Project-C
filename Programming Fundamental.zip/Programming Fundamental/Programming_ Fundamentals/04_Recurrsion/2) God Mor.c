#include <stdio.h>
void greeting(int n);

int main()
{
    int num;
    printf("Enter the Number :");
    scanf("%d", &num);
    greeting(num);
    return 0;
}
void greeting(int n)
{
    if (n == 0)
    {
        return;
    }
    else
    {
        printf(" * Good Morning\n");
        greeting(n - 1);
    }
}

// #include <stdio.h>
// void increasing(int current ,int limit);

// int main()
// {
//     int num;
//     printf("Enter the Number :");
//     scanf("%d", &num);
//     increasing(1,num);
//     return 0;
// }
// void increasing(int current ,int limit)

// {
//     if (current > limit)
//     {
//         return;
//     }
//     else
//     {
//         printf("%d\n",current);
//         return increasing(current + 1 ,limit);
//     }
// }

//               Recursive call

#include <stdio.h>

void increasing(int n);

int main()
{
    int num;
    printf("Enter the Number: ");
    scanf("%d", &num);
    increasing(num);
    return 0;
}

void increasing(int n)
{
    if (n == 0)  // Base case
    {
        return;
    }
    increasing(n - 1);  // First go to the smallest number
    printf("%d\n", n);  // Print during the returning phase
}

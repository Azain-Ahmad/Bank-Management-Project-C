# include <stdio.h>
int sum(int n);

    int main ()
    {
        int num;
        printf("Enter the Number :");
        scanf("%d" ,&num);
        int result = sum(num);
        printf("Sum of  number is %d" ,result);
        return 0;
    }
    int sum(int n )
    {
        if(n == 1 )
        {
            return 1;
        }
        else
        {
            int sum_Ans = n + sum(n-1);
            return sum_Ans;

        }
    }


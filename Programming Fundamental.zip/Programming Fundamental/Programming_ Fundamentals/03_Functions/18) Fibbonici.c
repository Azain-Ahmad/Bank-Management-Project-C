#include <stdio.h>
int fibbonaci(int n);
int main()
{
    int number;
    printf("Enter the number :");
    scanf("%d", &number);

    printf("Fibbonaci Result is %d", fibbonaci(number));
    return 0;
}
int fibbonaci(int n)
{

    if (n <= 2)
    {
        return 1;
    }
    else
    {
        // int ans1 = fibbonaci(n-1);
        // int ans2 = fibbonaci(n-2);
        // int Rec_Fibbonici = ans1 + ans2;
        int Rec_Fibbonici = fibbonaci(n - 1) + fibbonaci(n - 2);

        return Rec_Fibbonici;
    }
}

#include <stdio.h>
int max(int a, int b, int c);
int main()
{
    int num1, num2, num3;
    printf("Enter the First Number :");
    scanf("%d", &num1);
    printf("Enter the Second Number :");
    scanf("%d", &num2);
    printf("Enter the Third  Number :");
    scanf("%d", &num3);

    max(num1, num2, num3);

    return 0;
}
// Function Defination

int max(int a, int b, int c)
{
    if (a > b && a > c)
    {
        printf("%d is Maximum\n", a);
    }
    else if (b > a && b > c)
    {
        printf("%d is Maximum\n", b);
    }
    else
        printf("%d is maximum\n", c);
    return 0;
}

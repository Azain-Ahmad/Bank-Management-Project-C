# include <stdio.h>
int Reverse_Number(int n);
int main ()
{
    int number;
    printf("Enter the Number :");
    scanf("%d" ,&number);

    int result = Reverse_Number(number);
    printf("The Reverse of number is %d\n",result);
    return 0;
}
int Reverse_Number(int n)
{
    int reverse = 0;
    int remainder = 0;
    while(n !=0)
    {
        remainder = n % 10;
        reverse = reverse * 10 + remainder;
        n = n / 10;
    }
    return reverse;
}

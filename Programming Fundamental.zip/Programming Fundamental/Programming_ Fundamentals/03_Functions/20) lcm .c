#include <stdio.h>

int MAX(int x ,int y);
int LCM(int x ,int y);

int main()
{
    int a,b;
    printf("Enter the value of a :");
    scanf("%d" ,&a);
    printf("Enter the value of b :");
    scanf("%d" ,&b); 

    if (a == 0 || b == 0) {
        printf("LCM is not defined for zero.\n");
        return 1;
    }

    int result = LCM(a,b);
    printf("The LCM of %d AND %d  = %d\n", a, b, result);
    return 0;
}

int MAX(int a, int b)
{
    if(a > b)
        return a;
    else  
        return b;
}

int LCM(int x ,int y)
{
    int Pass_lcm;
    printf("MAX of %d and %d is: %d\n", x, y, MAX(x, y));  // debug
    for(int i = MAX(x,y); ; i++)
    {
        if(x % i == 0 && y % i == 0 )
        {
            Pass_lcm= i;
            break;
        }
    }
    return Pass_lcm;
}

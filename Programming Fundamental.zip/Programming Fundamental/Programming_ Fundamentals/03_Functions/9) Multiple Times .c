# include <stdio.h>
void multiple(int times);
int main()
{
    int num;
    printf("Enter the number :");
    scanf("%d" ,&num);

    multiple(num);


    return 0;
}
void multiple(int times)
{
    int i;
    for(i = 0; i<times; i++)
    printf("(%d)---<Welcome To the DR.Mazhar CLass >---\n" ,i+1);
}

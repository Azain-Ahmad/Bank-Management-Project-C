#include <stdio.h>
// Function Decleration

int Subtract(int a, int b);
int main()
{
    int num1, num2, Subtraction;
    printf("Enter the First Number :");
    scanf("%d", &num1);
    printf("Enter the Second Number :");
    scanf("%d", &num2);

    // Function call
    Subtraction = Subtract(num1, num2);
    printf("Subtarction is %d", Subtraction);
    return 0;
}
// Function Defination
int Subtract(int a, int b)
{
    return a - b;
}

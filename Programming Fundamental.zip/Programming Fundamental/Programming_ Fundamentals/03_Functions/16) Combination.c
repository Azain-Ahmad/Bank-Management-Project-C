# include <stdio.h>
int factorial(int x);

int main()
{

    int n , r ;
    printf("Enter the value of n :");
    scanf("%d" ,&n);

    printf("Enter the value of r :");
    scanf("%d" ,&r);

    if (r > n || n < 0 || r < 0) {
    printf("Invalid input! Ensure that n ≥ r and both are ≥ 0.\n");
    return 1;
}


    // int nfact =factorial(n);
    // int rfact = factorial(r);
    // int n_rfactorial = factorial(n-r);
    // int nCr = nfact / (rfact * n_rfactorial);

    int nCr = factorial(n) / (factorial(r) * factorial (n - r));
    printf("The Value of Combination is  :%d" ,nCr);
    return 0;

}
int factorial(int x)
{
    int fact = 1 ,i;
    for(i=2; i<=x; i++)
    {
        fact = fact * i;
    }
    return fact;
}

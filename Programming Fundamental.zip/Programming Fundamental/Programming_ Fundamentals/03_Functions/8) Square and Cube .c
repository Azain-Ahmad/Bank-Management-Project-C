#include <stdio.h>

int square(int a);
int cube(int y);
int main()
{
    int num;
    printf("Enter the Number :");
    scanf("%d", &num);

    int result1 =square(num);
    printf("Square is %d\n", result1);

    int result2 =cube(num);
    printf("Cube of a Number is %d\n", result2);

    return 0;
}
int square(int a)
{
    return a * a;
}
int cube(int y)
{
    return y * y * y;
}

# include <stdio.h>
int HCF(int x ,int y);
int main()
{
    int a,b;
    printf("Enter the value of a :");
    scanf("%d" ,&a);
    printf("Enter the value of a :");
    scanf("%d" ,&b); 

    int result = HCF(a,b);
    printf("The HCF of %d AND %d  = %d" ,a,b,result);
    return 0;
}
int min(int a, int b)
{
    if(a<b)
    return a;
    else  
     return b;
}
int HCF(int x ,int y)
{
    int Gcd;
    for(int i=min(x,y); i>=1; i--)
    {
        if(x % i == 0 && y % i == 0 )
        Gcd= i;
        break;
    }
    return Gcd;

}

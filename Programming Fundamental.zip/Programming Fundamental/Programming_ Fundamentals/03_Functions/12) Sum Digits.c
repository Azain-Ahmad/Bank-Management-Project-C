# include <stdio.h>

int Sum_Digit(int n);
int main()
{
int number;
printf("Enter Any Number :");
scanf("%d" ,&number);
int result = Sum_Digit(number);

printf("Sum of Digits of NUmber is %d" ,result);
return 0;
}
int Sum_Digit(int n)
{
    int sum = 0;
    int remainder = 0;
    while(n != 0)
    {
        remainder = n % 10;    // // Add the last digit to sum
        sum = sum + remainder;
        n= n / 10;  // Remove the last Digit from Sum
    }
    return sum;
}

#include <stdio.h>
// Function Decleration

int add(int a, int b);
int main()
{
    int num1, num2, Sum;
    printf("Enter the First Number :");
    scanf("%d", &num1);
    printf("Enter the Second Number :");
    scanf("%d", &num2);

    // Function call
    Sum = add(num1, num2);
    printf("Sum is %d", Sum);
    return 0;
}
// Function Defination
int add(int a, int b)
{
    return a + b;
}

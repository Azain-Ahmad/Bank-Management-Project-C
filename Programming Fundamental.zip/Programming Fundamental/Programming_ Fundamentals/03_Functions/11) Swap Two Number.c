# include <stdio.h>

// This is a function declaration (also called prototype).

//  1>  *a means the value stored at the address a.
//  2>  &num1 means the address of num1.
//  3>  This is called Call by Reference, and it allows a function to modify variables in the caller function.



void  swap(int *a,int *b);
int main()
{
    int num1, num2 ;
    printf("Enter the First Number :");
    scanf("%d", &num1);
    printf("Enter the Second Number :");
    scanf("%d", &num2);

    printf("Before Swaping\n a=%d and b=%d" ,num1,num2);
    
    swap(&num1, &num2);

    printf("\nAfter  Swaping\n a=%d and b=%d" ,num1,num2);

}
void swap(int *a,int *b)
{
    int temp;
    temp = *a;
    *a = *b;
    *b = temp;
}

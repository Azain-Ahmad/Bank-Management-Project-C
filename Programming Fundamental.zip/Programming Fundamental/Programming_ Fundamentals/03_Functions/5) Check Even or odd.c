#include <stdio.h>
void IS_even_odd(int n);
int main()
{
    int number;
    printf("Enter the number :");
    scanf("%d", &number);
    IS_even_odd(number);

    return 0;
}
void IS_even_odd(int n)
{
    if (n % 2 == 0)
        printf("%d is Even ", n);
    else
        printf("%d is Odd", n);
    // return 0;
}

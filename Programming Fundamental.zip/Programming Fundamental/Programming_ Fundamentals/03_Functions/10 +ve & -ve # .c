# include <stdio.h>
void  Positive_Negative(int a);
int main()
{
    int number;
    printf("Enter the number :");
    scanf("%d",&number);

    Positive_Negative(number);

    return 0;
}
void Positive_Negative(int a)
{
    if(a > 0)
    printf("%d is Positive Number \n " ,a);
    else if(a<0)
    printf("%d is Negative Number \n " ,a);
    else
    printf("The Number is 0 \n");

}


# include <stdio.h>
int power(int x, int y);
int main()
{
    int a , b;
    printf("Enter the value of a :");
    scanf("%d" ,&a);

    printf("Enter the value of b :");
    scanf("%d" ,&b);

    int p = power(a,b);
    printf("%d raised to  the power %d = %d" ,a,b,p);
    return 0;
}
int power(int x, int y)
{

    int z = 1;
    for(int i = 1; i<=y; i++)
    {
        z = z * x;
    }
    return z;


}

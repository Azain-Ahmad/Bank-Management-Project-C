#include <stdio.h>
#include <math.h>

// 92727  // 153    // 548834
// An Armstrong number (also called a narcissistic number) is a number that equals 
//  the sum of its own digits each raised to the power of the number of digits.
int IS_Armstrong(int n);
int main()
{
    int number;
    printf("Enter the number :");
    scanf("%d", &number);

    if (IS_Armstrong(number))
    {
        printf("%d is an Armstrong Number ", number);
    }
    else
    {
        printf("%d is not an Armstrong Number ", number);
    }

return 0;
}
int IS_Armstrong(int n)
{

    if (n < 0)
        return 0;

    int digit = 0;
    int sum = 0;
    int remainder = 0;
    int Orignal_number = n;
    while (n != 0)
    {
        digit++;
        n = n / 10;
    }
    n = Orignal_number;
    while (n != 0)
    {
        remainder = n % 10;
        sum = sum + pow(remainder, digit);
        n = n / 10;
    }
    return (sum == Orignal_number);
}

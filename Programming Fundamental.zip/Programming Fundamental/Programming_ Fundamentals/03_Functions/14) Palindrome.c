# include <stdio.h>
void IS_Palindrome(int n);
int main ()
{
    int number;
    printf("Enter the Number :");
    scanf("%d" ,&number);

IS_Palindrome(number);
    return 0;
}

void IS_Palindrome(int n)
{
    int Orignal_number = n;
    int reverse = 0;
    int remainder = 0;
    while(n !=0)
    {
        remainder = n % 10;
        reverse = reverse * 10 + remainder;
        n = n / 10;
    }
    if(reverse == Orignal_number)
    printf("The number %d is a  Palindrome ",Orignal_number);
    else
        printf("The number %d is not a  Palindrome ",Orignal_number);

}
